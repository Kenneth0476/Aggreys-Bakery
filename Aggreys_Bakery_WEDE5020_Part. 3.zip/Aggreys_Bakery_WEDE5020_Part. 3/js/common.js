/* =====================================================================
   Aggrey's Bakery - common.js  (WEDE5020 Part 3)
   Loaded on every page. Holds the helpers the other scripts share.

   CONTENTS
   1. The Bakery namespace (one global object, so no other globals leak)
   2. Small helpers (make elements safely, format money and dates)
   3. loadProducts()  - loads data/products.json with fetch() (AJAX)
   4. Scroll reveal   - cards and gallery pictures fade in as they scroll into view
   5. Mobile menu     - folds the navigation behind a Menu button on phones
   ===================================================================== */
(function () {
  'use strict';

  /* ---------------------------------------------------------------
     1. NAMESPACE
     All the site's scripts hang their functions off window.Bakery.
     --------------------------------------------------------------- */
  var Bakery = (window.Bakery = window.Bakery || {});

  // Tells the stylesheet that JavaScript is running, so it can switch on
  // the enhanced versions of the accordion, tabs and scroll reveal.
  document.documentElement.classList.add('js');

  /* ---------------------------------------------------------------
     2. SMALL HELPERS
     --------------------------------------------------------------- */

  // Friendly names for the category values stored in products.json
  Bakery.categoryNames = {
    bread: 'Bread',
    cakes: 'Cakes',
    confectionery: 'Confectionery'
  };

  /**
   * Creates an element. Text is added with textContent, never innerHTML,
   * so anything typed by a visitor can never run as code (XSS safe).
   * Example: Bakery.el('p', { class: 'price' }, 'R18')
   */
  Bakery.el = function (tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (name) {
      node.setAttribute(name, attrs[name]);
    });
    [].concat(children === undefined ? [] : children).forEach(function (child) {
      node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
    });
    return node;
  };

  // 1250 -> "R1 250"
  Bakery.formatRand = function (amount) {
    return 'R' + Number(amount).toLocaleString('en-ZA');
  };

  // Date -> "Friday, 6 November 2026"
  Bakery.formatDate = function (date) {
    return date.toLocaleDateString('en-ZA', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  };

  // Today at midnight (local time), so dates can be compared fairly
  Bakery.today = function () {
    var now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), now.getDate());
  };

  // Today + n days
  Bakery.addDays = function (date, days) {
    var copy = new Date(date.getTime());
    copy.setDate(copy.getDate() + days);
    return copy;
  };

  // "2026-11-06" -> local Date (new Date("2026-11-06") would use UTC)
  Bakery.parseDateInput = function (value) {
    var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    return parts ? new Date(+parts[1], +parts[2] - 1, +parts[3]) : null;
  };

  // Date -> "2026-11-06" (the format <input type="date"> uses)
  Bakery.toDateInput = function (date) {
    var m = String(date.getMonth() + 1).padStart(2, '0');
    var d = String(date.getDate()).padStart(2, '0');
    return date.getFullYear() + '-' + m + '-' + d;
  };

  // "Baked fresh daily" or "Order at least 3 days in advance"
  Bakery.availabilityText = function (product) {
    if (product.availability === 'order-ahead') {
      return 'Order at least ' + product.leadDays + (product.leadDays === 1 ? ' day' : ' days') + ' in advance';
    }
    return 'Baked fresh daily';
  };

  /* ---------------------------------------------------------------
     3. LOAD THE PRODUCT LIST (AJAX)
     fetch() asks the server for data/products.json without reloading
     the page. The answer is cached, so the Home, Products and Enquiry
     pages share one request. The promise rejects if the file cannot
     be loaded, and each page decides how to show that error.
     --------------------------------------------------------------- */
  var productRequest = null;

  Bakery.loadProducts = function () {
    if (!productRequest) {
      productRequest = fetch('data/products.json', { headers: { Accept: 'application/json' } })
        .then(function (response) {
          if (!response.ok) {
            throw new Error('Server answered ' + response.status);
          }
          return response.json();
        })
        .then(function (data) {
          if (!data || !Array.isArray(data.products)) {
            throw new Error('Product file has the wrong shape');
          }
          return data.products;
        })
        .catch(function (error) {
          productRequest = null;   // allow a retry later
          throw error;
        });
    }
    return productRequest;
  };

  /* ---------------------------------------------------------------
     4. SCROLL REVEAL
     Home page cards and gallery pictures that start below the fold are
     hidden by CSS (.reveal) and fade in once they enter the screen.
     Anything already visible on load is left alone, so nothing flashes.
     Uses IntersectionObserver. Printing shows everything (see style.css).
     --------------------------------------------------------------- */
  Bakery.reveal = function (root) {
    if (!('IntersectionObserver' in window)) { return; }
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    (root || document).querySelectorAll('.card, .gallery li').forEach(function (node) {
      if (node.getBoundingClientRect().top < window.innerHeight) { return; }
      node.classList.add('reveal');
      observer.observe(node);
    });
  };

  document.addEventListener('DOMContentLoaded', function () {
    Bakery.reveal();
  });

  /* ---------------------------------------------------------------
     5. MOBILE MENU
     On a phone the five links take two rows of the screen, so the menu
     is folded behind a "Menu" button. The button is made here (not in
     the HTML), so visitors without JavaScript simply keep the normal
     row of links. From 768px up the button is hidden by CSS and the
     links are always shown.
     --------------------------------------------------------------- */
  function setupMenu() {
    var header = document.querySelector('.site-header');
    var nav = header && header.querySelector('nav');
    if (!nav) { return; }
    if (!nav.id) { nav.id = 'main-nav'; }

    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'nav-toggle';
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-controls', nav.id);
    button.textContent = 'Menu';
    header.insertBefore(button, nav);
    header.classList.add('has-menu');   // tells the stylesheet the menu can fold

    function setOpen(open, returnFocus) {
      nav.classList.toggle('is-open', open);
      button.setAttribute('aria-expanded', String(open));
      button.textContent = open ? 'Close' : 'Menu';
      if (!open && returnFocus) { button.focus(); }
    }

    button.addEventListener('click', function () {
      setOpen(button.getAttribute('aria-expanded') !== 'true');
    });
    // Esc closes the menu and puts focus back on the button
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && nav.classList.contains('is-open')) { setOpen(false, true); }
    });
    // A click anywhere outside the header closes it too
    document.addEventListener('click', function (event) {
      if (nav.classList.contains('is-open') && !header.contains(event.target)) { setOpen(false); }
    });
    // Turning the phone sideways or widening the window resets the menu
    window.matchMedia('(min-width: 48em)').addEventListener('change', function (event) {
      if (event.matches) { setOpen(false); }
    });
  }
  setupMenu();
})();
