/* =====================================================================
   Aggrey's Bakery - catalogue.js  (WEDE5020 Part 3)
   Dynamic content: product cards that are built by JavaScript from
   data/products.json.

   CONTENTS
   1. buildCard()      - makes one product card (photo, text, buttons) with DOM methods
   2. Home page        - "Popular at the bakery" (featured products)
   3. Products page    - search, category filter, sort, details modal
   ===================================================================== */
(function () {
  'use strict';

  var Bakery = window.Bakery;
  var el = Bakery.el;

  /* ---------------------------------------------------------------
     1. BUILD ONE PRODUCT CARD
     The card is created with createElement and textContent (through
     Bakery.el), so product text can never be run as HTML.
     --------------------------------------------------------------- */
  /* The product photo: a square picture, WebP first with a JPG fallback.
     File names follow the pattern images/aggreys-bakery-<name>-400.webp */
  function productPicture(product, sizes, loading) {
    var base = 'images/aggreys-bakery-' + product.image;
    return el('picture', { 'class': 'product-photo' }, [
      el('source', { type: 'image/webp', srcset: base + '-320.webp 320w, ' + base + '-400.webp 400w', sizes: sizes }),
      el('img', {
        src: base + '-400.jpg', srcset: base + '-400.jpg 400w', sizes: sizes,
        width: '400', height: '400', loading: loading || 'lazy', decoding: 'async', alt: product.imageAlt || ''
      })
    ]);
  }

  function buildCard(product, onDetails, photoSizes) {
    var actions = el('p', { 'class': 'actions' });

    if (onDetails) {
      var detailsButton = el('button', { type: 'button', 'class': 'button-outline' }, 'Details');
      detailsButton.setAttribute('aria-label', 'Details for ' + product.name);
      detailsButton.addEventListener('click', function () { onDetails(product, detailsButton); });
      actions.appendChild(detailsButton);
    }

    var askLink = el('a', {
      'class': 'button',
      href: 'enquiry.html?product=' + encodeURIComponent(product.id)
    }, 'Ask about this');
    askLink.setAttribute('aria-label', 'Ask about ' + product.name);
    actions.appendChild(askLink);

    // Tells the browser how wide the photo is shown, so it downloads the right file size
    photoSizes = photoSizes || '(min-width: 90em) 300px, (min-width: 64em) 260px, (min-width: 48em) 46vw, 100vw';
    return el('article', { 'class': 'product-card' }, [
      product.image ? productPicture(product, photoSizes) : '',
      el('p', { 'class': 'product-tag' }, Bakery.categoryNames[product.category]),
      el('h3', {}, product.name),
      el('p', {}, product.description),
      el('p', { 'class': 'price' }, [el('strong', {}, Bakery.formatRand(product.price)), ' ' + product.unit]),
      el('p', { 'class': 'availability' }, Bakery.availabilityText(product)),
      actions
    ]);
  }

  /* A short error message with a Try again button */
  function showLoadError(container, retry) {
    var again = el('button', { type: 'button', 'class': 'button-outline' }, 'Try again');
    again.addEventListener('click', retry);
    container.replaceChildren(
      el('div', { 'class': 'message message-error', role: 'alert' }, [
        el('p', {}, 'We could not load the product list. Please check your internet connection and try again.'),
        el('p', {}, again)
      ])
    );
  }

  /* ---------------------------------------------------------------
     2. HOME PAGE: POPULAR PRODUCTS
     The HTML already contains a link to the Products page. If the
     product list loads, the link is replaced by the featured cards.
     --------------------------------------------------------------- */
  function initFeatured(container) {
    Bakery.loadProducts().then(function (products) {
      var featured = products.filter(function (product) { return product.featured; });
      if (!featured.length) { return; }
      container.replaceChildren.apply(container, featured.map(function (p) { return buildCard(p, null, '(min-width: 90em) 400px, (min-width: 64em) 360px, (min-width: 48em) 46vw, 100vw'); }));
    }).catch(function () {
      /* Leave the plain link in place; the page still works without the list */
    });
  }

  /* ---------------------------------------------------------------
     3. PRODUCTS PAGE: SEARCH, FILTER, SORT AND DETAILS
     --------------------------------------------------------------- */
  function initCatalogue() {
    var list = document.getElementById('catalogue-list');
    var search = document.getElementById('cat-search');
    var category = document.getElementById('cat-category');
    var sort = document.getElementById('cat-sort');
    var count = document.getElementById('cat-count');
    var dialog = document.getElementById('product-dialog');
    var products = [];

    /* ----- the details modal ----- */
    function showDetails(product, opener) {
      if (!dialog || typeof dialog.showModal !== 'function') { return; }
      var photo = document.getElementById('pd-photo');
      if (photo) { photo.replaceChildren(product.image ? productPicture(product, '288px', 'eager') : ''); }
      document.getElementById('pd-title').textContent = product.name;
      document.getElementById('pd-category').textContent = Bakery.categoryNames[product.category];
      document.getElementById('pd-description').textContent = product.description;
      document.getElementById('pd-price').textContent = Bakery.formatRand(product.price) + ' ' + product.unit;
      document.getElementById('pd-availability').textContent = Bakery.availabilityText(product);
      document.getElementById('pd-link').setAttribute('href', 'enquiry.html?product=' + encodeURIComponent(product.id));
      dialog.showModal();
      dialog.addEventListener('close', function () { opener.focus(); }, { once: true });
    }
    if (dialog) { Bakery.enhanceDialog(dialog); }

    /* ----- filter, sort and draw the cards ----- */
    function render() {
      var query = search.value.trim().toLowerCase();
      var chosen = category.value;

      var shown = products.filter(function (product) {
        var inCategory = chosen === 'all' || product.category === chosen;
        var text = (product.name + ' ' + product.description + ' ' + Bakery.categoryNames[product.category]).toLowerCase();
        return inCategory && (!query || text.indexOf(query) !== -1);
      });

      shown.sort(function (a, b) {
        if (sort.value === 'price-low')  { return a.price - b.price || a.name.localeCompare(b.name); }
        if (sort.value === 'price-high') { return b.price - a.price || a.name.localeCompare(b.name); }
        return a.name.localeCompare(b.name);
      });

      if (!shown.length) {
        var clear = el('button', { type: 'button', 'class': 'button-outline' }, 'Clear search and filters');
        clear.addEventListener('click', function () {
          search.value = '';
          category.value = 'all';
          sort.value = 'name';
          render();
          search.focus();
        });
        list.replaceChildren(el('div', { 'class': 'message' }, [
          el('p', {}, 'No products match your search. Try a different word, or clear the filters.'),
          el('p', {}, clear)
        ]));
      } else {
        list.replaceChildren.apply(list, shown.map(function (p) { return buildCard(p, showDetails); }));
      }

      // role="status" on this paragraph tells screen readers the new result count
      count.textContent = 'Showing ' + shown.length + ' of ' + products.length + ' products.';
    }

    function load() {
      list.replaceChildren(el('p', { 'class': 'message' }, 'Loading products...'));
      Bakery.loadProducts().then(function (loaded) {
        products = loaded;
        render();
      }).catch(function () {
        count.textContent = '';
        showLoadError(list, load);
      });
    }

    search.addEventListener('input', render);
    category.addEventListener('change', render);
    sort.addEventListener('change', render);

    // Pressing Enter inside the search box must not reload the page
    document.getElementById('catalogue-controls').addEventListener('submit', function (event) {
      event.preventDefault();
    });

    load();
  }

  /* ---------------------------------------------------------------
     START-UP
     --------------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    var featured = document.getElementById('popular-list');
    if (featured) { initFeatured(featured); }
    if (document.getElementById('catalogue-list')) { initCatalogue(); }
  });
})();
