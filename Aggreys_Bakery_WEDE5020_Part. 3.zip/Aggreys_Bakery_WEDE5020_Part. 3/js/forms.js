/* =====================================================================
   Aggrey's Bakery - forms.js  (WEDE5020 Part 3)
   Form validation, error messages, the enquiry response and the
   contact email.

   CONTENTS
   1. SETTINGS        - the email address the contact form sends to
   2. Validators      - one small function per kind of input
   3. Form helper     - shows errors, validates on submit and on blur
   4. Enquiry form    - dependent product list, price estimate, AJAX send
   5. Contact form    - builds an email the visitor can send
   ===================================================================== */
(function () {
  'use strict';

  var Bakery = window.Bakery;
  var el = Bakery.el;

  /* ---------------------------------------------------------------
     1. SETTINGS
     The contact form builds an email addressed to this recipient.
     (example.com is a reserved address, so no real person gets mail
     while the project is being marked. Change it to a real address.)
     --------------------------------------------------------------- */
  var RECIPIENT_EMAIL = 'aggreysbakery@example.com';

  /* ---------------------------------------------------------------
     2. VALIDATORS
     Each one returns an error message, or '' when the value is fine.
     --------------------------------------------------------------- */
  var check = {
    name: function (value) {
      value = value.trim();
      if (!value) { return 'Enter your full name.'; }
      if (value.length < 2 || value.length > 60) { return 'Your name must be between 2 and 60 characters long.'; }
      if (!/^[\p{L}][\p{L} '\u2019.\-]*$/u.test(value)) { return 'Use letters, spaces, hyphens and apostrophes only.'; }
      return '';
    },

    email: function (value) {
      value = value.trim();
      if (!value) { return 'Enter your email address.'; }
      if (value.length > 100) { return 'Your email address must be 100 characters or fewer.'; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) { return 'Enter an email address like name@example.com.'; }
      return '';
    },

    // Optional. Accepts South African numbers such as 012 345 6789,
    // 082-123-4567 or +27 82 123 4567 (spaces, dashes and brackets are ignored).
    phone: function (value) {
      var digits = value.replace(/[\s\-()]/g, '');
      if (!digits) { return ''; }
      if (!/^(\+27|0)[1-9][0-9]{8}$/.test(digits)) {
        return 'Enter a South African phone number, like 012 345 6789 or +27 82 123 4567.';
      }
      return '';
    },

    required: function (message) {
      return function (value) { return value ? '' : message; };
    },

    quantity: function (value) {
      var number = Number(value);
      if (value === '') { return 'Enter how many you would like.'; }
      if (!Number.isInteger(number)) { return 'Enter a whole number, like 2.'; }
      if (number < 1 || number > 100) { return 'Enter a number from 1 to 100.'; }
      return '';
    },

    // Optional. The date must be today or later, and within six months.
    date: function (value) {
      if (!value) { return ''; }
      var chosen = Bakery.parseDateInput(value);
      if (!chosen) { return 'Enter a valid date.'; }
      var today = Bakery.today();
      if (chosen < today) { return 'Choose today or a date in the future.'; }
      if (chosen > Bakery.addDays(today, 180)) { return 'Choose a date within the next six months.'; }
      return '';
    },

    length: function (label, min, max) {
      return function (value) {
        var length = value.trim().length;
        if (!length) { return 'Enter your ' + label + '.'; }
        if (length < min) { return 'Your ' + label + ' must be at least ' + min + ' characters long (now ' + length + ').'; }
        if (length > max) { return 'Your ' + label + ' must be ' + max + ' characters or fewer (now ' + length + ').'; }
        return '';
      };
    },

    consent: function (_value, input) {
      return input.checked ? '' : 'Tick the box to say we may contact you.';
    }
  };

  /* ---------------------------------------------------------------
     3. FORM HELPER
     rules = [{ id: 'enq-name', test: check.name }, ...]
     Gives a form: error messages next to each field, an error summary
     at the top, checking when a field is left, and checking again
     when the form is submitted.
     --------------------------------------------------------------- */
  function FormChecker(form, summary, rules) {
    this.form = form;
    this.summary = summary;
    this.rules = rules;
    form.noValidate = true;   // we show our own messages instead of the browser's

    var self = this;
    rules.forEach(function (rule) {
      var input = document.getElementById(rule.id);
      // Check a field as soon as the visitor leaves it...
      input.addEventListener('blur', function () { self.checkField(rule); });
      // ...and re-check while typing, but only once an error is showing
      var recheck = function () {
        if (input.getAttribute('aria-invalid') === 'true') { self.checkField(rule); }
      };
      input.addEventListener('input', recheck);
      input.addEventListener('change', recheck);
    });
  }

  // Skips rules whose field is hidden (for example the product list)
  FormChecker.prototype.isActive = function (rule) {
    var input = document.getElementById(rule.id);
    return !input.closest('[hidden]') && !input.disabled;
  };

  FormChecker.prototype.checkField = function (rule) {
    var input = document.getElementById(rule.id);
    var message = this.isActive(rule) ? rule.test(input.value, input) : '';
    var errorBox = document.getElementById(rule.id + '-error');

    if (message) {
      input.setAttribute('aria-invalid', 'true');
      errorBox.textContent = message;
      errorBox.hidden = false;
    } else {
      input.removeAttribute('aria-invalid');
      errorBox.textContent = '';
      errorBox.hidden = true;
    }
    return message;
  };

  // Returns true when every field is valid. Otherwise shows the errors.
  FormChecker.prototype.checkAll = function () {
    var self = this;
    var problems = [];

    this.rules.forEach(function (rule) {
      var message = self.checkField(rule);
      if (message) { problems.push({ id: rule.id, message: message }); }
    });

    var list = this.summary.querySelector('ul');
    list.replaceChildren();

    if (!problems.length) {
      this.summary.hidden = true;
      return true;
    }

    problems.forEach(function (problem) {
      var link = el('a', { href: '#' + problem.id }, problem.message);
      link.addEventListener('click', function (event) {
        event.preventDefault();
        document.getElementById(problem.id).focus();
      });
      list.appendChild(el('li', {}, link));
    });
    this.summary.hidden = false;
    this.summary.focus();   // moves keyboard and screen reader users to the list of problems
    return false;
  };

  FormChecker.prototype.reset = function () {
    this.summary.hidden = true;
    this.rules.forEach(function (rule) {
      var input = document.getElementById(rule.id);
      var errorBox = document.getElementById(rule.id + '-error');
      input.removeAttribute('aria-invalid');
      errorBox.textContent = '';
      errorBox.hidden = true;
    });
  };

  // Live "123 / 500" counter under a text area
  function addCounter(textarea, output, max) {
    function update() { output.textContent = textarea.value.length + ' / ' + max + ' characters'; }
    textarea.addEventListener('input', update);
    textarea.form.addEventListener('reset', function () { setTimeout(update, 0); });
    update();
  }

  /* ---------------------------------------------------------------
     4. ENQUIRY FORM
     - The product list depends on the topic that was chosen.
     - When the form is valid, a price and availability answer is
       worked out and shown.
     - The enquiry is also sent to the server with fetch() (AJAX),
       without reloading the page.
     --------------------------------------------------------------- */
  function initEnquiry(form) {
    var topic = document.getElementById('enq-topic');
    var productField = document.getElementById('enq-product-field');
    var product = document.getElementById('enq-product');
    var quantityField = document.getElementById('enq-quantity-field');
    var quantity = document.getElementById('enq-quantity');
    var date = document.getElementById('enq-date');
    var message = document.getElementById('enq-message');
    var result = document.getElementById('enq-result');
    var products = [];

    // The earliest date a visitor can choose is today
    date.min = Bakery.toDateInput(Bakery.today());
    date.max = Bakery.toDateInput(Bakery.addDays(Bakery.today(), 180));
    addCounter(message, document.getElementById('enq-message-count'), 500);

    var checker = new FormChecker(form, document.getElementById('enq-errors'), [
      { id: 'enq-name',     test: check.name },
      { id: 'enq-email',    test: check.email },
      { id: 'enq-phone',    test: check.phone },
      { id: 'enq-topic',    test: check.required('Choose what your enquiry is about.') },
      { id: 'enq-product',  test: check.required('Choose a product.') },
      { id: 'enq-quantity', test: check.quantity },
      { id: 'enq-date',     test: check.date },
      { id: 'enq-message',  test: check.length('message', 10, 500) },
      { id: 'enq-consent',  test: check.consent }
    ]);

    /* ----- Dependent select: show only the products in the chosen topic ----- */
    function fillProducts(selectedId) {
      var category = topic.value;
      var wanted = products.filter(function (item) { return item.category === category; });
      var showProducts = wanted.length > 0;

      productField.hidden = !showProducts;
      quantityField.hidden = !showProducts;
      product.replaceChildren(el('option', { value: '' }, 'Choose one'));

      wanted.forEach(function (item) {
        var label = item.name + ' (' + Bakery.formatRand(item.price) + ' ' + item.unit + ')';
        product.appendChild(el('option', { value: item.id }, label));
      });
      if (selectedId) { product.value = selectedId; }
    }
    topic.addEventListener('change', function () { fillProducts(); });

    /* ----- Load the product list, then honour ?product=birthday-cake ----- */
    Bakery.loadProducts().then(function (loaded) {
      products = loaded;
      var wantedId = new URLSearchParams(window.location.search).get('product');
      var match = products.filter(function (item) { return item.id === wantedId; })[0];
      if (match) {
        topic.value = match.category;
        fillProducts(match.id);
      } else if (topic.value) {
        fillProducts();
      }
    }).catch(function () {
      // Without the list the form still works; the bakery replies by email instead
      document.getElementById('enq-load-note').hidden = false;
    });

    /* ----- Work out the answer shown to the visitor ----- */
    function buildAnswer(data) {
      var item = products.filter(function (p) { return p.id === data.product; })[0];
      var box = el('div', { 'class': 'flow' });
      box.appendChild(el('h2', {}, 'Thank you, ' + data.name.trim().split(/\s+/)[0]));

      if (!item) {
        box.appendChild(el('p', {}, 'We have your enquiry about ' + (data.topic === 'custom' ? 'a bulk or custom order' : 'your question') +
          '. We will reply to ' + data.email.trim() + ' with prices and availability.'));
        return box;
      }

      var qty = Number(data.quantity);
      var earliest = Bakery.addDays(Bakery.today(), item.leadDays);
      var rows = [
        ['Product', item.name],
        ['Quantity', String(qty)],
        ['Estimated price', Bakery.formatRand(item.price * qty) + ' (' + Bakery.formatRand(item.price) + ' ' + item.unit + ')'],
        ['Availability', Bakery.availabilityText(item)],
        ['Earliest date', Bakery.formatDate(earliest)]
      ];
      var list = el('dl', { 'class': 'answer' });
      rows.forEach(function (row) {
        list.appendChild(el('dt', {}, row[0]));
        list.appendChild(el('dd', {}, row[1]));
      });
      box.appendChild(el('p', {}, 'Here is what we can tell you about your enquiry:'));
      box.appendChild(list);

      if (data.date) {
        var wanted = Bakery.parseDateInput(data.date);
        box.appendChild(el('p', { 'class': wanted < earliest ? 'message message-warning' : 'message message-ok' },
          wanted < earliest
            ? 'You asked for ' + Bakery.formatDate(wanted) + ', which is earlier than we can manage for this product. The earliest date is ' + Bakery.formatDate(earliest) + '.'
            : 'Your date, ' + Bakery.formatDate(wanted) + ', gives us enough time.'));
      }
      box.appendChild(el('p', { 'class': 'hint' }, 'This is an estimate. We will confirm the final price and date by email.'));
      return box;
    }

    /* ----- Send the enquiry with fetch() (AJAX) ----- */
    function send(formData, status, fallbackLink) {
      var body = new URLSearchParams();
      formData.forEach(function (value, key) { body.append(key, value); });

      status.textContent = 'Sending your enquiry to the bakery...';

      return fetch(form.getAttribute('action'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
      }).then(function (response) {
        if (!response.ok) { throw new Error('Server answered ' + response.status); }
        status.textContent = 'Your enquiry was sent. We will reply to ' + String(formData.get('email')).trim() + '.';
        status.className = 'message message-ok';
      }).catch(function () {
        status.className = 'message message-warning';
        status.replaceChildren(
          'We could not send your enquiry online. ',
          fallbackLink,
          ' to email it instead.'
        );
      });
    }

    /* ----- Submit: check first, then answer and send ----- */
    form.addEventListener('submit', function (event) {
      event.preventDefault();   // stay on the page; the answer appears below the form
      result.hidden = true;

      if (!checker.checkAll()) { return; }

      var formData = new FormData(form);
      var data = {
        name: form.elements.name.value,
        email: form.elements.email.value,
        topic: topic.value,
        product: product.value,
        quantity: quantity.value,
        date: date.value
      };

      var status = el('p', { 'class': 'message', role: 'status' });
      var mailSubject = 'Enquiry from ' + data.name.trim();
      var mailBody = 'Topic: ' + topic.options[topic.selectedIndex].text + '\n\n' + message.value.trim();
      var emailLink = el('a', {
        href: 'mailto:' + RECIPIENT_EMAIL + '?subject=' + encodeURIComponent(mailSubject) + '&body=' + encodeURIComponent(mailBody)
      }, 'Use this link');

      result.replaceChildren(buildAnswer(data), status);
      result.hidden = false;
      result.focus();
      result.scrollIntoView({ behavior: 'smooth', block: 'start' });

      // Switch the button off while the request is on its way, so a double click cannot send twice
      var submitButton = form.querySelector('[type="submit"]');
      submitButton.disabled = true;
      send(formData, status, emailLink).then(function () { submitButton.disabled = false; });
    });

    form.addEventListener('reset', function () {
      checker.reset();
      result.hidden = true;
      // After the browser has cleared the fields, hide the product list again
      setTimeout(function () { fillProducts(); }, 0);
    });
  }

  /* ---------------------------------------------------------------
     5. CONTACT FORM
     When the form is valid, the details are put together into an
     email. The visitor checks it and presses "Open in my email app"
     to send it to the recipient set at the top of this file.
     --------------------------------------------------------------- */
  function initContact(form) {
    var type = document.getElementById('con-type');
    var message = document.getElementById('con-message');
    var result = document.getElementById('con-result');
    var mailLink = document.getElementById('con-mailto');
    var copyButton = document.getElementById('con-copy');
    var copyStatus = document.getElementById('con-copy-status');
    var emailText = '';

    addCounter(message, document.getElementById('con-message-count'), 1000);
    document.getElementById('con-recipient').textContent = RECIPIENT_EMAIL;

    var checker = new FormChecker(form, document.getElementById('con-errors'), [
      { id: 'con-name',    test: check.name },
      { id: 'con-email',   test: check.email },
      { id: 'con-phone',   test: check.phone },
      { id: 'con-type',    test: check.required('Choose the type of message.') },
      { id: 'con-subject', test: check.length('subject', 5, 80) },
      { id: 'con-message', test: check.length('message', 10, 1000) }
    ]);

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      result.hidden = true;
      copyStatus.textContent = '';

      if (!checker.checkAll()) { return; }

      var typeLabel = type.options[type.selectedIndex].text;
      var phone = form.elements.phone.value.trim();
      var subject = '[' + typeLabel + '] ' + form.elements.subject.value.trim();

      // The body is plain text. Line breaks are written as \r\n for email programs.
      var lines = [
        "Hello Aggrey's Bakery,",
        '',
        message.value.trim(),
        '',
        'Message type: ' + typeLabel,
        'Name: ' + form.elements.name.value.trim(),
        'Email: ' + form.elements.email.value.trim(),
        'Phone: ' + (phone || 'not given'),
        '',
        "Sent from the Aggrey's Bakery website contact form."
      ];
      var body = lines.join('\r\n');
      emailText = 'To: ' + RECIPIENT_EMAIL + '\nSubject: ' + subject + '\n\n' + body.replace(/\r\n/g, '\n');

      mailLink.setAttribute('href', 'mailto:' + RECIPIENT_EMAIL +
        '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body));
      document.getElementById('con-preview-subject').textContent = subject;
      document.getElementById('con-preview-body').textContent = body.replace(/\r\n/g, '\n');

      result.hidden = false;
      result.focus();
      result.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    // Some computers have no email program, so the message can also be copied
    copyButton.addEventListener('click', function () {
      if (!navigator.clipboard) {
        copyStatus.textContent = 'Copying is not available in this browser. Select the text above and copy it by hand.';
        return;
      }
      navigator.clipboard.writeText(emailText).then(function () {
        copyStatus.textContent = 'Copied. Paste it into an email to ' + RECIPIENT_EMAIL + '.';
      }).catch(function () {
        copyStatus.textContent = 'Could not copy. Select the text above and copy it by hand.';
      });
    });

    form.addEventListener('reset', function () {
      checker.reset();
      result.hidden = true;
      copyStatus.textContent = '';
    });
  }

  /* ---------------------------------------------------------------
     START-UP
     --------------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    var enquiry = document.getElementById('enquiry-form');
    var contact = document.getElementById('contact-form');
    if (enquiry) { initEnquiry(enquiry); }
    if (contact) { initContact(contact); }
  });
})();
