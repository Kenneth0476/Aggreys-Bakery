/* =====================================================================
   Aggrey's Bakery - widgets.js  (WEDE5020 Part 3)
   Interactive elements built with plain JavaScript (no framework, so
   there is nothing extra to download).

   CONTENTS
   1. Dialog helper   - close buttons and click-outside-to-close
   2. Tabs            - About page      ([data-tabs])
   3. Accordion       - Contact page    ([data-accordion])
   4. Gallery lightbox- Products page   ([data-gallery])

   Every widget starts from ordinary HTML that already works without
   JavaScript (progressive enhancement). The script then adds the
   interactive behaviour and the ARIA attributes that go with it.
   ===================================================================== */
(function () {
  'use strict';

  var Bakery = (window.Bakery = window.Bakery || {});
  document.documentElement.classList.add('js');

  /* ---------------------------------------------------------------
     1. DIALOG HELPER
     The <dialog> element gives us a modal for free: it traps focus,
     closes with the Escape key and dims the page behind it. This
     helper adds the two things it does not do by itself.
     --------------------------------------------------------------- */
  Bakery.enhanceDialog = function (dialog) {
    // Any element marked data-close closes the dialog
    dialog.querySelectorAll('[data-close]').forEach(function (button) {
      button.addEventListener('click', function () { dialog.close(); });
    });
    // A click on the dark backdrop lands on the <dialog> itself
    dialog.addEventListener('click', function (event) {
      if (event.target === dialog) { dialog.close(); }
    });
  };

  /* ---------------------------------------------------------------
     2. TABS
     Pattern: https://www.w3.org/WAI/ARIA/apg/patterns/tabs/
     Click a tab, or use the arrow keys, Home and End.
     --------------------------------------------------------------- */
  function initTabs(root) {
    var tabs = [].slice.call(root.querySelectorAll('[role="tab"]'));
    var panels = tabs.map(function (tab) {
      return document.getElementById(tab.getAttribute('aria-controls'));
    });

    function select(index, moveFocus) {
      tabs.forEach(function (tab, i) {
        var active = i === index;
        tab.setAttribute('aria-selected', String(active));
        tab.tabIndex = active ? 0 : -1;       // only the active tab is in the Tab order
        panels[i].hidden = !active;
        if (active) {
          // Restart the fade-in animation on the newly shown panel
          panels[i].classList.remove('tab-enter');
          void panels[i].offsetWidth;          // forces the browser to notice the change
          panels[i].classList.add('tab-enter');
        }
      });
      if (moveFocus) { tabs[index].focus(); }
    }

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () { select(index, false); });
      tab.addEventListener('keydown', function (event) {
        var last = tabs.length - 1;
        var target = null;
        if (event.key === 'ArrowRight') { target = index === last ? 0 : index + 1; }
        if (event.key === 'ArrowLeft')  { target = index === 0 ? last : index - 1; }
        if (event.key === 'Home')       { target = 0; }
        if (event.key === 'End')        { target = last; }
        if (target !== null) {
          event.preventDefault();
          select(target, true);
        }
      });
    });

    select(0, false);   // show the first tab, hide the others
  }

  /* ---------------------------------------------------------------
     3. ACCORDION
     Pattern: https://www.w3.org/WAI/ARIA/apg/patterns/accordion/
     Each question is a button. aria-expanded tells screen readers
     whether the answer is open; CSS animates the height.
     --------------------------------------------------------------- */
  function initAccordion(root) {
    root.querySelectorAll('button[aria-controls]').forEach(function (button) {
      var panel = document.getElementById(button.getAttribute('aria-controls'));
      button.setAttribute('aria-expanded', 'false');
      panel.removeAttribute('data-open');

      button.addEventListener('click', function () {
        var open = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!open));
        if (open) {
          panel.removeAttribute('data-open');
        } else {
          panel.setAttribute('data-open', '');
        }
      });
    });
  }

  /* ---------------------------------------------------------------
     4. GALLERY LIGHTBOX
     Each thumbnail is a normal link to the large picture, so without
     JavaScript it still opens the image. With JavaScript the click is
     caught and the picture opens in the lightbox <dialog> instead.
     --------------------------------------------------------------- */
  function initGallery(list) {
    var dialog = document.getElementById('lightbox');
    if (!dialog || typeof dialog.showModal !== 'function') { return; }

    var links = [].slice.call(list.querySelectorAll('a[data-large]'));
    var image = dialog.querySelector('img');
    var caption = dialog.querySelector('figcaption');
    var counter = dialog.querySelector('[data-count]');
    var current = 0;
    var opener = null;

    function show(index) {
      current = (index + links.length) % links.length;   // wraps round at both ends
      var link = links[current];
      image.src = link.getAttribute('data-large');
      image.alt = link.querySelector('img').alt;
      caption.textContent = link.getAttribute('data-caption');
      counter.textContent = 'Picture ' + (current + 1) + ' of ' + links.length;
    }

    links.forEach(function (link, index) {
      link.addEventListener('click', function (event) {
        event.preventDefault();
        opener = link;
        show(index);
        dialog.showModal();
      });
    });

    dialog.querySelector('[data-prev]').addEventListener('click', function () { show(current - 1); });
    dialog.querySelector('[data-next]').addEventListener('click', function () { show(current + 1); });

    dialog.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft')  { show(current - 1); }
      if (event.key === 'ArrowRight') { show(current + 1); }
    });

    // Put keyboard focus back on the thumbnail that was clicked
    dialog.addEventListener('close', function () {
      if (opener) { opener.focus(); }
    });

    Bakery.enhanceDialog(dialog);
  }

  /* ---------------------------------------------------------------
     START-UP: set up every widget that exists on this page
     --------------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-tabs]').forEach(initTabs);
    document.querySelectorAll('[data-accordion]').forEach(initAccordion);
    document.querySelectorAll('[data-gallery]').forEach(initGallery);
  });
})();
