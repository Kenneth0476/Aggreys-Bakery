/* =====================================================================
   Aggrey's Bakery - map.js  (WEDE5020 Part 3)
   Interactive map on the Contact page, made with Leaflet and
   OpenStreetMap tiles (both free, no account or API key needed).

   PAGE SPEED: Leaflet is a large library, so it is NOT loaded with the
   page. It is only downloaded when the visitor scrolls close to the
   map. Visitors who never reach the map never download it.

   SECURITY: the Leaflet files carry an "integrity" hash (Subresource
   Integrity). The browser refuses the file if even one byte differs
   from the version we checked.
   ===================================================================== */
(function () {
  'use strict';

  var box = document.getElementById('map');
  if (!box) { return; }

  // Approximate position of Danville Extension 16, Pretoria West.
  // Replace with the exact shop position if it is known.
  var POSITION = [-25.7536, 28.1273];

  var LEAFLET_CSS = {
    href: 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
    integrity: 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY='
  };
  var LEAFLET_JS = {
    src: 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
    integrity: 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo='
  };

  function showFallback() {
    var note = box.querySelector('.map-note');
    if (note) {
      note.textContent = 'The map could not be loaded. Use the "Open in Google Maps" link instead.';
    }
  }

  function drawMap() {
    box.replaceChildren();   // remove the "loading" note

    var map = L.map(box, { scrollWheelZoom: false }).setView(POSITION, 15);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // A pin drawn with CSS, so no extra image files are needed
    var pin = L.divIcon({ className: 'map-pin', iconSize: [28, 28], iconAnchor: [14, 28], popupAnchor: [0, -26] });

    var popup = document.createElement('div');
    var title = document.createElement('strong');
    title.textContent = "Aggrey's Bakery";
    popup.appendChild(title);
    popup.appendChild(document.createElement('br'));
    popup.appendChild(document.createTextNode('Danville Extension 16, Pretoria West'));
    popup.appendChild(document.createElement('br'));
    popup.appendChild(document.createTextNode('(approximate position)'));

    L.marker(POSITION, { icon: pin, title: "Aggrey's Bakery" }).addTo(map).bindPopup(popup).openPopup();
  }

  function loadLeaflet() {
    var style = document.createElement('link');
    style.rel = 'stylesheet';
    style.href = LEAFLET_CSS.href;
    style.integrity = LEAFLET_CSS.integrity;
    style.crossOrigin = '';
    document.head.appendChild(style);

    var script = document.createElement('script');
    script.src = LEAFLET_JS.src;
    script.integrity = LEAFLET_JS.integrity;
    script.crossOrigin = '';
    script.onload = drawMap;
    script.onerror = showFallback;
    document.head.appendChild(script);
  }

  // Start loading when the map is about 300px from the screen
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) {
        observer.disconnect();
        loadLeaflet();
      }
    }, { rootMargin: '300px' });
    observer.observe(box);
  } else {
    loadLeaflet();
  }
})();
